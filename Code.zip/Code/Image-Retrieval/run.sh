#!/bin/bash
python3 train.py --dataset cub

python3 train.py --dataset cars

python3 train.py --dataset sop

